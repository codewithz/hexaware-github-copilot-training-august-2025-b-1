package com.hexaware.spring_boot_playground;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPlaygroundApplicationTests {

	@Test
	void contextLoads() {
	}

}
